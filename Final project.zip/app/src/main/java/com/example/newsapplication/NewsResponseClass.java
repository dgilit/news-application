package com.example.newsapplication;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class NewsResponseClass {
    @SerializedName("status")
    private String status;
    @SerializedName("code")
    private String code;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("totalResults")
    private int totalResults;
    @SerializedName("articles")
    private ArrayList<NewsDataResponseClass> NewsDataResponseClass;


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getTotalResults() {
        return totalResults;
    }

    public void setTotalResults(int totalResults) {
        this.totalResults = totalResults;
    }

    public ArrayList<NewsDataResponseClass> getNewsDataResponseClass() {
        return NewsDataResponseClass;
    }

    public void setNewsDataResponseClass(ArrayList<NewsDataResponseClass> newsDataResponseClass) {
        NewsDataResponseClass = newsDataResponseClass;
    }

    @Override
    public String toString() {
        return "NewsResponseClass{" +
                "status='" + status + '\'' +
                ", code='" + code + '\'' +
                ", message='" + message + '\'' +
                ", totalResults=" + totalResults +
                ", NewsDataResponseClass=" + NewsDataResponseClass +
                '}';
    }
}
