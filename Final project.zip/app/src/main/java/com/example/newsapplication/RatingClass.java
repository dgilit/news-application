package com.example.newsapplication;

public class RatingClass {
    private String id;
    private String email;
    private String rating;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    @Override
    public String toString() {
        return "RatingClass{" +
                "id='" + id + '\'' +
                ", email='" + email + '\'' +
                ", rating='" + rating + '\'' +
                '}';
    }
}
