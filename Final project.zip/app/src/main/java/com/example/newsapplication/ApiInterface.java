package com.example.newsapplication;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
//http://newsapi.org/v2/everything?q=bitcoin&from=2020-03-16&sortBy=publishedAt&apiKey=44169e616cf341d59d10b7b91b5f0a02&page=1
public interface ApiInterface {
    @GET("everything")
    Call<NewsResponseClass> getNewsData(@Query("q") String q,
                                        @Query("from") String from,
                                        @Query("sortBy") String sortBy,
                                        @Query("apiKey") String apiKey,
                                        @Query("page") int page);
}
