package com.example.newsapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class BookmarkedNewsAdapter extends RecyclerView.Adapter<BookmarkedNewsAdapter.ViewHolder> {

    private ArrayList<NewsDataResponseClass> mBookmarkedNewsDataResponseArrayList;
    private Context mContext;
    private NewsDataAdapter.onCLickListener mOnCLickListener;

    public interface onCLickListener {
        public void onCLick(View view, int position);
    }

    public BookmarkedNewsAdapter(Context context, ArrayList<NewsDataResponseClass> newsDataResponseArrayList, NewsDataAdapter.onCLickListener onCLickListener) {
        mContext = context;
        mBookmarkedNewsDataResponseArrayList = newsDataResponseArrayList;
        mOnCLickListener = onCLickListener;
    }

    public void updateData(ArrayList<NewsDataResponseClass> newsDataResponseArrayList) {
        mBookmarkedNewsDataResponseArrayList = newsDataResponseArrayList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public BookmarkedNewsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_layout, parent, false);
        return new BookmarkedNewsAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookmarkedNewsAdapter.ViewHolder holder, int position) {
        //convert date
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        Date date = null;
        try {
            date = dateFormat.parse(mBookmarkedNewsDataResponseArrayList.get(position).getPublishedAt());//You will get date object relative to server/client timezone wherever it is parsed
        } catch (ParseException e) {
            e.printStackTrace();
        }
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        holder.tvPublishedAt.setText(formatter.format(date));

        if (mBookmarkedNewsDataResponseArrayList.get(position).getAuthor() != null && !mBookmarkedNewsDataResponseArrayList.get(position).getAuthor().equals("")) {
            holder.tvAuthorName.setText(mBookmarkedNewsDataResponseArrayList.get(position).getAuthor());
        } else {
            holder.tvDash.setVisibility(View.GONE);
            holder.tvAuthorName.setVisibility(View.GONE);
        }

        holder.tvTitle.setText(mBookmarkedNewsDataResponseArrayList.get(position).getTitle());
        final int[] lineCount = {2};
        holder.tvTitle.post(new Runnable() {
            @Override
            public void run() {
                lineCount[0] = holder.tvTitle.getLineCount();
                // Use lineCount here
                if (lineCount[0] == 1) {
                    holder.tvDetail.setMaxLines(2);
                } else {
                    holder.tvDetail.setMaxLines(1);
                }
            }
        });

        holder.tvDetail.setText(mBookmarkedNewsDataResponseArrayList.get(position).getDescription());
        holder.cvNewsDetail.getLayoutParams().height = (int) (mContext.getResources().getDisplayMetrics().heightPixels / 3.5);
        holder.cvNewsDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mOnCLickListener.onCLick(v, position);
            }
        });

        holder.ivMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mOnCLickListener.onCLick(v, position);
            }
        });
        Glide.with(mContext)
                .load(mBookmarkedNewsDataResponseArrayList.get(position).getUrlToImage())
                .centerCrop()
//                .placeholder(R.drawable.news_placeholder)
                .into(holder.ivNewsImage);

    }

    @Override
    public int getItemCount() {
        return mBookmarkedNewsDataResponseArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView tvPublishedAt;
        private TextView tvTitle;
        private TextView tvDetail;
        private TextView tvAuthorName, tvDash;
        private ImageView ivNewsImage, ivMore;
        private CardView cvNewsDetail;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            ivMore = itemView.findViewById(R.id.ivMore);
            tvDash = itemView.findViewById(R.id.tvDash);
            tvAuthorName = itemView.findViewById(R.id.tvAuthorName);
            tvPublishedAt = itemView.findViewById(R.id.tvPublishedAt);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvDetail = itemView.findViewById(R.id.tvDetail);
            ivNewsImage = itemView.findViewById(R.id.ivNewsImage);
            cvNewsDetail = itemView.findViewById(R.id.cvNewsDetail);
        }
    }
}
