package com.example.newsapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.ContactsContract;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DatabaseAdapter extends SQLiteOpenHelper {
    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "rating_db";

    private static final String TABLE_NAME = "rating_detail";
    private static final String ID = "id";
    private static final String EMAIL = "email";
    private static final String RATING = "rating";


    public DatabaseAdapter(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + "("
                + ID + " TEXT PRIMARY KEY ,"
                + EMAIL + " TEXT,"
                + RATING + " TEXT"
                + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertRateingRow(String id, String email, String rating) {
        // get writable database as we want to write data
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        // `id` and `timestamp` will be inserted automatically.
        // no need to add them
        values.put(ID, id);
        values.put(EMAIL, email);
        values.put(RATING, rating);

        // insert row
        db.insert(TABLE_NAME, null, values);

        // close db connection
        db.close();
    }

    public void updateRating(String id, String rating) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(RATING, rating);

        // updating row
        db.update(TABLE_NAME, values, ID + " = ?",
                new String[]{String.valueOf(id)});

        db.close();
    }

    public ArrayList<RatingClass> getAllRatings() {
        ArrayList<RatingClass> notes = new ArrayList<>();

        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_NAME + "  " +
                ID;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                RatingClass ratingClass = new RatingClass();
                ratingClass.setId(cursor.getString(cursor.getColumnIndex(ID)));
                ratingClass.setEmail(cursor.getString(cursor.getColumnIndex(EMAIL)));
                ratingClass.setRating(cursor.getString(cursor.getColumnIndex(RATING)));

                notes.add(ratingClass);
            } while (cursor.moveToNext());
        }

        // close db connection
        db.close();

        // return notes list
        return notes;
    }
}
