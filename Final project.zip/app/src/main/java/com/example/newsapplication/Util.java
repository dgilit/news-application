package com.example.newsapplication;

public class Util {
    public static String BOOKMARKED_NEWS = "bookmarked_news";
    public static String EMAIL = "email";

    public static boolean isValidEmail(CharSequence target) {
        return target != null && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }
}
