package com.example.newsapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity {

    private boolean isLoading = false;
    private boolean isLastPage = false;
    private boolean alreadyrated = false;
    private int currentPage = 0;
    private int PAGE_SIZE = 20;

    private String TAG = getClass().getName();
    //    String googleNewsApiKey = "44169e616cf341d59d10b7b91b5f0a02";
    private String googleNewsApiKey = "ec724285e5f6416ebcb9ae631ed5319b";
    private String date;
    private ArrayList<NewsDataResponseClass> newsResponseArrayList = new ArrayList<>();
    private ArrayList<NewsDataResponseClass> bookmarkNewsArrayList = new ArrayList<>();
    private ArrayList<RatingClass> ratingClassArrayList = new ArrayList<>();

    private RecyclerView.LayoutManager layoutManager;
    private NewsDataAdapter adapter;

    private ImageView ivBookmark;
    private RecyclerView rvNewsList;

    private TinyDB tinydb;
    private DatabaseAdapter databaseAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tinydb = new TinyDB(this);
        databaseAdapter = new DatabaseAdapter(this);

        bookmarkNewsArrayList = tinydb.getListObject(Util.BOOKMARKED_NEWS);
        ratingClassArrayList = databaseAdapter.getAllRatings();

        date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        Log.e(TAG, "onCreate: date " + date);

        ivBookmark = findViewById(R.id.ivBookmark);
        rvNewsList = findViewById(R.id.rvNewsList);
        rvNewsList.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getApplicationContext());
        rvNewsList.setLayoutManager(layoutManager);

        ivBookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, BookmarkListActivity.class);
                startActivity(intent);
            }
        });

        //for pagination
        rvNewsList.addOnScrollListener(new PaginationListener((LinearLayoutManager) layoutManager) {
            @Override
            protected void loadMoreItems() {
                isLoading = true;
                callNewsAPI();
            }

            @Override
            public boolean isLastPage() {
                return isLastPage;
            }

            @Override
            public boolean isLoading() {
                return isLoading;
            }
        });
        callNewsAPI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        bookmarkNewsArrayList = tinydb.getListObject(Util.BOOKMARKED_NEWS);
        ratingClassArrayList = databaseAdapter.getAllRatings();
    }

    private void callNewsAPI() {

        if (isNetworkAvailable()) {
            isLoading = true;
            currentPage += 1;

            ApiInterface apiService = ApiClient.getClient().create(ApiInterface.class);

            Call<NewsResponseClass> call = apiService.getNewsData("bitcoin", date, "publishedAt", googleNewsApiKey, currentPage);
            call.enqueue(new Callback<NewsResponseClass>() {
                @Override
                public void onResponse(Call<NewsResponseClass> call, Response<NewsResponseClass> response) {
                    if (response.body() != null && response.isSuccessful()) {
                        Log.e(TAG, "onResponse: call.request().url() " + call.request().url());
                        Log.e(TAG, "onResponse: response.body().getStatus() " + response.body().getStatus());
                        if (response.body().getStatus().equalsIgnoreCase("ok")) {
                            for (int i = 0; i < response.body().getNewsDataResponseClass().size(); i++) {
                                newsResponseArrayList.add(response.body().getNewsDataResponseClass().get(i));
                            }

                            Log.e(TAG, " response.body().getNewsDataResponseClass(): " + response.body().getNewsDataResponseClass());
                            Log.e(TAG, " response.body().getNewsDataResponseClass().size(): " + response.body().getNewsDataResponseClass().size());
                            Log.e(TAG, "newsResponseArrayList.size(): " + newsResponseArrayList.size());
                            Log.e(TAG, "newsResponseArrayList: " + newsResponseArrayList);

                            isLoading = false;

                            if (adapter != null) {
                                adapter.updateData(newsResponseArrayList);
                            } else {
                                adapter = new NewsDataAdapter(getApplicationContext(), newsResponseArrayList, new NewsDataAdapter.onCLickListener() {
                                    @Override
                                    public void onCLick(View view, int position) {
                                        if (view.getId() == R.id.cvNewsDetail) {
                                            Intent intent = new Intent(MainActivity.this, NewsDetailActivity.class);
                                            intent.putExtra("newslink", newsResponseArrayList.get(position).getUrl());
                                            startActivity(intent);
                                        } else {
                                            final Dialog dialog = new Dialog(MainActivity.this);
                                            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                            dialog.setContentView(R.layout.moredialog);

                                            LinearLayout llShare = dialog.findViewById(R.id.llShare);
                                            LinearLayout llBookmark = dialog.findViewById(R.id.llBookmark);
                                            LinearLayout llRate = dialog.findViewById(R.id.llRate);
                                            TextView tvBookmark = dialog.findViewById(R.id.tvBookmark);
                                            TextView tvRate = dialog.findViewById(R.id.tvRate);

                                            DecimalFormatSymbols otherSymbols = new DecimalFormatSymbols(Locale.US);
                                            DecimalFormat df = new DecimalFormat("#.#", otherSymbols);


                                            for (RatingClass ratingClass : ratingClassArrayList) {
                                                if (ratingClass.getId().equals(newsResponseArrayList.get(position).getPublishedAt())) {
                                                    tvRate.setText(df.format(Float.parseFloat(ratingClass.getRating())) + " " + "Stars");
                                                    alreadyrated = true;
                                                    break;
                                                } else {
                                                    alreadyrated = false;
                                                    tvRate.setText(getResources().getString(R.string.rate_news));
                                                }
                                            }

                                            for (NewsDataResponseClass bookmarkDataResponseClass : bookmarkNewsArrayList) {
                                                if (bookmarkDataResponseClass.getPublishedAt().equals(newsResponseArrayList.get(position).getPublishedAt())) {
                                                    tvBookmark.setText(getResources().getString(R.string.remove_bookmark));
                                                } else {
                                                    tvBookmark.setText(getResources().getString(R.string.bookmark));
                                                }
                                            }

                                            llRate.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {

                                                    dialog.cancel();

                                                    if (tinydb.getString(Util.EMAIL).isEmpty() || tinydb.getString(Util.EMAIL).equalsIgnoreCase("")) {
                                                        final Dialog dialog = new Dialog(MainActivity.this);
                                                        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                                        dialog.setContentView(R.layout.dialog_email);

                                                        EditText etEmail = dialog.findViewById(R.id.etEmail);
                                                        LinearLayout llSubmit = dialog.findViewById(R.id.llSubmit);

                                                        etEmail.addTextChangedListener(new TextWatcher() {
                                                            @Override
                                                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                                                            }

                                                            @Override
                                                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                                                            }

                                                            @Override
                                                            public void afterTextChanged(Editable s) {
                                                                if (s.toString().isEmpty()) {
                                                                    llSubmit.setAlpha(0.5f);
                                                                    llSubmit.setClickable(false);
                                                                } else {
                                                                    llSubmit.setAlpha(1f);
                                                                    llSubmit.setClickable(true);
                                                                }
                                                            }
                                                        });
                                                        llSubmit.setOnClickListener(new View.OnClickListener() {
                                                            @Override
                                                            public void onClick(View v) {
                                                                if (Util.isValidEmail(etEmail.getText().toString())) {
                                                                    dialog.cancel();
                                                                    tinydb.putString(Util.EMAIL, etEmail.getText().toString());
                                                                    showRatingDialog(position);

                                                                } else {
                                                                    Toast.makeText(MainActivity.this, R.string.enter_valid_email_msg, Toast.LENGTH_LONG).show();
                                                                }
                                                            }
                                                        });

                                                        dialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.90), LinearLayout.LayoutParams.WRAP_CONTENT);
                                                        dialog.getWindow().setGravity(Gravity.CENTER);
                                                        dialog.show();
                                                    } else {
                                                        showRatingDialog(position);
                                                    }
                                                }
                                            });

                                            llBookmark.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    dialog.cancel();

                                                    if (tvBookmark.getText().toString().equalsIgnoreCase(getResources().getString(R.string.bookmark))) {
                                                        bookmarkNewsArrayList.add(newsResponseArrayList.get(position));
                                                    } else {
                                                        for (NewsDataResponseClass bookmarkDataResponseClass : bookmarkNewsArrayList) {
                                                            if (bookmarkDataResponseClass.getPublishedAt().equalsIgnoreCase(newsResponseArrayList.get(position).getPublishedAt())) {
                                                                bookmarkNewsArrayList.remove(bookmarkDataResponseClass);
                                                            }
                                                        }
                                                    }
                                                    tinydb.putListObject(Util.BOOKMARKED_NEWS, bookmarkNewsArrayList);

                                                }
                                            });

                                            llShare.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    try {
                                                        dialog.cancel();
                                                        Intent shareIntent = new Intent(Intent.ACTION_SEND);
                                                        shareIntent.setType("text/plain");
                                                        shareIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
                                                        String shareMessage = newsResponseArrayList.get(position).getUrl();
                                                        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                                                        startActivity(Intent.createChooser(shareIntent, "Choose one"));
                                                    } catch (Exception e) {
                                                        //e.toString();
                                                    }
                                                }
                                            });

                                            dialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.90), LinearLayout.LayoutParams.WRAP_CONTENT);
                                            dialog.getWindow().setGravity(Gravity.CENTER);
                                            dialog.show();
                                        }
                                    }
                                });
                                rvNewsList.setAdapter(adapter);
                            }

                            if (newsResponseArrayList.size() < PAGE_SIZE || newsResponseArrayList.size() == 0 || response.body().getNewsDataResponseClass().size() == 0) {
                                isLoading = true;
                                date = getPreviousDayDate();
                                currentPage = 0;
                                callNewsAPI();
                            }

                        } else {
                            isLoading = false;
                            Log.e(TAG, "error: " + response.body().getMessage());
                            Toast.makeText(MainActivity.this, response.body().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    } else {
                        isLoading = false;
                        Gson gson = new Gson();
                        TypeAdapter<NewsResponseClass> adapter = gson.getAdapter(NewsResponseClass.class);
                        try {
                            NewsResponseClass registerResponse = null;
                            if (response.errorBody() != null)
                                registerResponse =
                                        adapter.fromJson(
                                                response.errorBody().string());
                            Log.e(TAG, "onResponse: registerResponse" + registerResponse);
                            if (registerResponse != null)
                                Toast.makeText(MainActivity.this, registerResponse.getMessage(), Toast.LENGTH_LONG).show();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
//                    Log.e(TAG, "error: else " + response.body());
//                    Toast.makeText(MainActivity.this,  response.message(), Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onFailure(Call<NewsResponseClass> call, Throwable t) {
                    // Log error here since request failed
                    Log.e("Main ", t.toString());
                }
            });
        } else {
            Toast.makeText(this, R.string.no_internet, Toast.LENGTH_LONG).show();
        }
    }

    private void showRatingDialog(int position) {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_rating);

        LinearLayout llSubmit = dialog.findViewById(R.id.llSubmit);
        RatingBar rbNewsRating = dialog.findViewById(R.id.rbNewsRating);

        rbNewsRating.setNumStars(5);

        llSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
                Log.e(TAG, "onClickrate: EMAIL: " + tinydb.getString(Util.EMAIL));
                Log.e(TAG, "onClickrate: getRating " + rbNewsRating.getRating());
                if (alreadyrated) {
                    databaseAdapter.updateRating(newsResponseArrayList.get(position).getPublishedAt(), String.valueOf(rbNewsRating.getRating()));
                } else {
                    databaseAdapter.insertRateingRow(newsResponseArrayList.get(position).getPublishedAt(), tinydb.getString(Util.EMAIL), String.valueOf(rbNewsRating.getRating()));
                }
                ratingClassArrayList = databaseAdapter.getAllRatings();
                Toast.makeText(MainActivity.this, R.string.rate_success_msg, Toast.LENGTH_SHORT).show();
            }
        });

        dialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.90), LinearLayout.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.show();
    }

    private String getPreviousDayDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Date date1 = null;
        try {
            date1 = dateFormat.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date1);
        calendar.add(Calendar.DATE, -1);
        String yesterdayAsString = dateFormat.format(calendar.getTime());
        return yesterdayAsString;
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

}
