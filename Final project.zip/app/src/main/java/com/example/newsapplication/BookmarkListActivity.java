package com.example.newsapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Locale;

public class BookmarkListActivity extends AppCompatActivity {

    private boolean alreadyrated = false;
    private String TAG = getClass().getName();

    private RecyclerView rvBookmarkedNewsList;
    private TextView tvNoBookmark;
    private ImageView ivBack;
    private RecyclerView.LayoutManager layoutManager;

    private ArrayList<NewsDataResponseClass> bookmarkNewsArrayList = new ArrayList<>();
    private ArrayList<RatingClass> ratingClassArrayList = new ArrayList<>();

    private TinyDB tinydb;
    private BookmarkedNewsAdapter adapter;
    private DatabaseAdapter databaseAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmark_list);

        tinydb = new TinyDB(this);
        databaseAdapter = new DatabaseAdapter(this);

        bookmarkNewsArrayList = tinydb.getListObject(Util.BOOKMARKED_NEWS);
        ratingClassArrayList = databaseAdapter.getAllRatings();

        tvNoBookmark = findViewById(R.id.tvNoBookmark);
        rvBookmarkedNewsList = findViewById(R.id.rvBookmarkedNewsList);
        ivBack = findViewById(R.id.ivBack);

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        rvBookmarkedNewsList.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getApplicationContext());
        rvBookmarkedNewsList.setLayoutManager(layoutManager);

        showUI();

        adapter = new BookmarkedNewsAdapter(getApplicationContext(), bookmarkNewsArrayList, new NewsDataAdapter.onCLickListener() {
            @Override
            public void onCLick(View view, int position) {
                if (view.getId() == R.id.cvNewsDetail) {
                    Intent intent = new Intent(BookmarkListActivity.this, NewsDetailActivity.class);
                    intent.putExtra("newslink", bookmarkNewsArrayList.get(position).getUrl());
                    startActivity(intent);
                } else {
                    final Dialog dialog = new Dialog(BookmarkListActivity.this);
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    dialog.setContentView(R.layout.moredialog);

                    LinearLayout llShare = dialog.findViewById(R.id.llShare);
                    LinearLayout llBookmark = dialog.findViewById(R.id.llBookmark);
                    LinearLayout llRate = dialog.findViewById(R.id.llRate);
                    TextView tvBookmark = dialog.findViewById(R.id.tvBookmark);
                    TextView tvRate = dialog.findViewById(R.id.tvRate);

                    DecimalFormatSymbols otherSymbols = new DecimalFormatSymbols(Locale.US);
                    DecimalFormat df = new DecimalFormat("#.#", otherSymbols);

                    for (RatingClass ratingClass : ratingClassArrayList) {
                        if (ratingClass.getId().equals(bookmarkNewsArrayList.get(position).getPublishedAt())) {
                            tvRate.setText(df.format(Float.parseFloat(ratingClass.getRating())) + " " + "Stars");
                            alreadyrated = true;
                            break;
                        } else {
                            alreadyrated = false;
                            tvRate.setText(getResources().getString(R.string.rate_news));
                        }
                    }

//                    llShare.setVisibility(View.GONE);
//                    llRate.setVisibility(View.GONE);
//                    llShare.setVisibility(View.GONE);

                    llRate.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            dialog.cancel();

                            if (tinydb.getString(Util.EMAIL).isEmpty() || tinydb.getString(Util.EMAIL).equalsIgnoreCase("")) {
                                final Dialog dialog = new Dialog(BookmarkListActivity.this);
                                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                dialog.setContentView(R.layout.dialog_email);

                                EditText etEmail = dialog.findViewById(R.id.etEmail);
                                LinearLayout llSubmit = dialog.findViewById(R.id.llSubmit);

                                etEmail.addTextChangedListener(new TextWatcher() {
                                    @Override
                                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                                    }

                                    @Override
                                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                                    }

                                    @Override
                                    public void afterTextChanged(Editable s) {
                                        if (s.toString().isEmpty()) {
                                            llSubmit.setAlpha(0.5f);
                                            llSubmit.setClickable(false);
                                        } else {
                                            llSubmit.setAlpha(1f);
                                            llSubmit.setClickable(true);
                                        }
                                    }
                                });
                                llSubmit.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        if (Util.isValidEmail(etEmail.getText().toString())) {
                                            dialog.cancel();
                                            tinydb.putString(Util.EMAIL, etEmail.getText().toString());
                                            showRatingDialog(position);

                                        } else {
                                            Toast.makeText(BookmarkListActivity.this, R.string.enter_valid_email_msg, Toast.LENGTH_LONG).show();
                                        }
                                    }
                                });

                                dialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.90), LinearLayout.LayoutParams.WRAP_CONTENT);
                                dialog.getWindow().setGravity(Gravity.CENTER);
                                dialog.show();
                            } else {
                                showRatingDialog(position);
                            }
                        }
                    });
                    tvBookmark.setText(getResources().getString(R.string.remove_bookmark));

                    llBookmark.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.cancel();
                            bookmarkNewsArrayList.remove(position);
                            adapter.updateData(bookmarkNewsArrayList);
                            showUI();
                            tinydb.putListObject(Util.BOOKMARKED_NEWS, bookmarkNewsArrayList);
                        }
                    });

                    llShare.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            try {
                                dialog.cancel();
                                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                                shareIntent.setType("text/plain");
                                shareIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
                                String shareMessage = bookmarkNewsArrayList.get(position).getUrl();
                                shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                                startActivity(Intent.createChooser(shareIntent, "Choose one"));
                            } catch (Exception e) {
                                //e.toString();
                            }
                        }
                    });

                    dialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.90), LinearLayout.LayoutParams.WRAP_CONTENT);
                    dialog.getWindow().setGravity(Gravity.CENTER);
                    dialog.show();
                }
            }
        });
        rvBookmarkedNewsList.setAdapter(adapter);
    }

    private void showUI() {
        if (bookmarkNewsArrayList.size() == 0) {
            tvNoBookmark.setVisibility(View.VISIBLE);
            rvBookmarkedNewsList.setVisibility(View.GONE);
        } else {
            tvNoBookmark.setVisibility(View.GONE);
            rvBookmarkedNewsList.setVisibility(View.VISIBLE);
        }
    }

    private void showRatingDialog(int position) {
        final Dialog dialog = new Dialog(BookmarkListActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_rating);

        LinearLayout llSubmit = dialog.findViewById(R.id.llSubmit);
        RatingBar rbNewsRating = dialog.findViewById(R.id.rbNewsRating);

        rbNewsRating.setNumStars(5);

        llSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
                Log.e(TAG, "onClickrate: EMAIL: " + tinydb.getString(Util.EMAIL));
                Log.e(TAG, "onClickrate: getRating " + rbNewsRating.getRating());
                if (alreadyrated) {
                    databaseAdapter.updateRating(bookmarkNewsArrayList.get(position).getPublishedAt(), String.valueOf(rbNewsRating.getRating()));
                } else {
                    databaseAdapter.insertRateingRow(bookmarkNewsArrayList.get(position).getPublishedAt(), tinydb.getString(Util.EMAIL), String.valueOf(rbNewsRating.getRating()));
                }
                ratingClassArrayList = databaseAdapter.getAllRatings();
                Toast.makeText(BookmarkListActivity.this, R.string.rate_success_msg, Toast.LENGTH_SHORT).show();
            }
        });

        dialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.90), LinearLayout.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.show();
    }

}
